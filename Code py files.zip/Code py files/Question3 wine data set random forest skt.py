#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split, RandomizedSearchCV, ShuffleSplit
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score


# In[2]:


# Step 1: Load the wine dataset
wine = load_wine()
X, y = wine.data, wine.target


# In[3]:


# Step 2: Split the dataset into train and test dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[4]:


# Step 3: Use random search CV to hyperparameter tune the Decision Tree
param_dist = {
    'criterion': ['gini', 'entropy'],
    'max_depth': [None, 10, 20, 30, 40, 50],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['auto', 'sqrt', 'log2', None]
}

tree = DecisionTreeClassifier()
random_search = RandomizedSearchCV(tree, param_distributions=param_dist, n_iter=100, cv=5, random_state=42)
random_search.fit(X_train, y_train)


# In[5]:


print("Best Hyperparameters for Decision Tree:", random_search.best_params_)


# In[6]:


# Evaluate Decision Tree
tree_best = random_search.best_estimator_
y_pred_tree = tree_best.predict(X_test)
accuracy_tree = accuracy_score(y_test, y_pred_tree)
print("Accuracy of Decision Tree:", accuracy_tree)


# In[7]:


# Step 4: Grow a random forest
# Create 10 subsets of the training dataset
cv = ShuffleSplit(n_splits=10, test_size=0.2, random_state=42)


# In[8]:


# Train 1 decision tree on each subset
trees = []
for train_index, _ in cv.split(X_train):
    tree = DecisionTreeClassifier(**random_search.best_params_)
    tree.fit(X_train[train_index], y_train[train_index])
    trees.append(tree)


# In[9]:


# Evaluate all the trees on the test dataset
accuracies = []
for tree in trees:
    y_pred_tree = tree.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred_tree)
    accuracies.append(accuracy)


# In[10]:


# Calculate average accuracy of the trees in the random forest
average_accuracy_rf = sum(accuracies) / len(accuracies)
print("Average Accuracy of Random Forest:", average_accuracy_rf)


# In[ ]:




