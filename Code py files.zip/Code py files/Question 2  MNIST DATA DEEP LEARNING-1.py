#!/usr/bin/env python
# coding: utf-8

# In[1]:


from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam


# In[2]:


# Load MNIST dataset
(x_train, y_train), (x_test, y_test) = mnist.load_data()


# In[3]:


# Preprocess data (normalize pixel values to range [0, 1])
x_train = x_train.astype('float32') / 255
x_test = x_test.astype('float32') / 255


# In[4]:


# Reshape data for input layer (28x28 pixels)
x_train = x_train.reshape(x_train.shape[0], 28 * 28)
x_test = x_test.reshape(x_test.shape[0], 28 * 28)


# In[5]:


# Convert class labels to one-hot encoded vectors
from tensorflow.keras.utils import to_categorical
y_train = to_categorical(y_train)
y_test = to_categorical(y_test)


# In[6]:


# Define the Pure ANN model with less than 10,000 trainable parameters
model = Sequential()
model.add(Dense(512, activation='relu', input_shape=(28 * 28,)))  # First layer with 512 neurons
model.add(Dense(128, activation='relu'))  # Second layer with 128 neurons
model.add(Dense(10, activation='softmax'))  # Output layer with 10 neurons (one for each digit class)


# In[7]:


# Compile the model
model.compile(loss='categorical_crossentropy', optimizer=Adam(learning_rate=0.001), metrics=['accuracy'])


# In[8]:


# Train the model 
model.fit(x_train, y_train, epochs=10, batch_size=128, validation_data=(x_test, y_test))


# In[9]:


# Evaluate the model on test data
test_loss, test_acc = model.evaluate(x_test, y_test)
print('Test accuracy:', test_acc)


# In[10]:


# Count the total number of trainable parameters
total_params = model.count_params()
print('Total trainable parameters:', total_params)

