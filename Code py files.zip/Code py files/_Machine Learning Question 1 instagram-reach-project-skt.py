#!/usr/bin/env python
# coding: utf-8

# In[1]:



import numpy as np  
import pandas as pd  
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


data=pd.read_csv("instagram_reach.csv")


# In[4]:


data.head()


# In[5]:


data.isnull().sum()


# In[6]:


data.duplicated().sum()


# In[7]:


data.info()


# In[8]:


data.shape


# In[9]:


data.describe().T


# In[10]:


plt.figure(figsize=(15,10))
sns.histplot(data=data, x='Followers', bins=30, kde=True)
plt.show()


# In[11]:


from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()

data['USERNAME']=le.fit_transform(data['USERNAME'])
data['Caption']=le.fit_transform(data['Caption'])
data['Hashtags']=le.fit_transform(data['Hashtags'])


# In[12]:


data['Time since posted'] = data['Time since posted'].str.extract('(\d+)').astype(int)


# In[13]:


data


# In[14]:


X=data.drop(labels=['S.No','Time since posted','Likes'],axis=1)


# In[15]:


X


# In[16]:


print(data.columns)


# In[17]:


print(data.columns)


# In[18]:


y = data[['Time since posted','Likes']]


# In[19]:


y


# In[20]:


from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y, test_size=0.25)


# In[21]:


X_train


# In[22]:


y_train


# In[23]:


from sklearn.preprocessing import StandardScaler
scaler=StandardScaler()


# In[24]:


X_train_scaled=scaler.fit_transform(X_train)


# In[25]:


X_test_scaled=scaler.transform(X_test)


# In[26]:


from sklearn.linear_model import LinearRegression,Ridge,Lasso,ElasticNet
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import r2_score,mean_absolute_error, mean_squared_error


# In[27]:


def evaluate_model(true, predict):
    r2=r2_score(true, predict)
    mae=mean_absolute_error(true,predict)
    mse=mean_squared_error(true,predict)
   

    return r2, mae,mse,


# In[28]:


models={

    'LinearRegression':LinearRegression(),
    'Lasso':Lasso(),
    'Ridge':Ridge(),
    'Elasticnet':ElasticNet(),
    'Randomforest':RandomForestRegressor()

}


# In[29]:


for i in range(len(models)):
    model=list((models.values()))[i]
    print(model)
    
    
r2_list=[]


# In[30]:


from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error


# In[31]:


def evaluate_model(true, predict):
    r2=r2_score(true, predict)
    mae=mean_absolute_error(true,predict)
    mse=mean_squared_error(true,predict)
   

    return r2, mae,mse,


# In[32]:


for i in range(len(models)):
    model=list(models.values())[i]
    
    model.fit(X_train,y_train)

    #make_prediction
    y_pred=model.predict(X_test)

    #this is for the validaiton
    R2,MAE,MSE=evaluate_model(y_test,y_pred)


    print("model training performance",model)
    print("MSE:", MSE)
    print("MAE:",MAE)
    print("R2 SCORE:",R2)
    
    r2_list.append(R2)

    print("="*40)
    print("\n")

    


    


# In[33]:



r2_list


# # RandomForestRegressor has high r2 value and low mae and mse than other models, so it is best for our project
