#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score


# In[2]:


# Load the dataset
data = pd.read_csv("Bengaluru_House_Data.csv")


# In[3]:


data


# In[4]:


# Display basic information about the dataset
data.info()


# In[5]:


data.describe()


# ## EDA

# In[6]:


# Explore data distribution (histograms, boxplots)
data.hist(figsize=(10, 10))
plt.suptitle("Distribution of Bengaluru Housing Data")
plt.show()

data.plot(kind="box", subplots=True, layout=(3, 3), figsize=(15, 15))
plt.suptitle("Boxplots of Bengaluru Housing Data")
plt.tight_layout()
plt.show()

# Analyze numerical features (descriptive statistics, correlations)
print(data.describe(include="all"))

correlation = data.corr(method="spearman")  # Use Spearman's rank for mixed data types
print("Correlation matrix:\n", correlation)


# In[7]:


# Check for missing values
print(data.isnull().sum())


# In[8]:


# Drop rows with missing values
data.dropna(inplace=True)


# In[9]:


# Visualize distribution of target variable
plt.figure(figsize=(10, 6))
sns.histplot(data['price'], kde=True)
plt.title('Distribution of House Prices')
plt.xlabel('Price')
plt.ylabel('Frequency')
plt.show()


# In[10]:


# Visualize relationship between numerical features and target variable
sns.pairplot(data[['total_sqft', 'bath', 'balcony', 'price']])
plt.show()


# In[11]:


# Feature Engineering
# Convert categorical variables to numerical using one-hot encoding
data = pd.get_dummies(data, columns=['area_type', 'availability', 'location', 'size', 'society', 'total_sqft'], drop_first=True)


# In[12]:


# Scale numerical features
scaler = StandardScaler()
numerical_cols = ['bath', 'balcony']
data[numerical_cols] = scaler.fit_transform(data[numerical_cols])


# In[13]:


# Train-test split
X = data.drop(columns=['price'])
y = data['price']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[14]:


# Model Training
svm_regressor = SVR(kernel='linear')
svm_regressor.fit(X_train, y_train)


# In[15]:


# Model Evaluation
y_pred_train = svm_regressor.predict(X_train)
y_pred_test = svm_regressor.predict(X_test)
train_mse = mean_squared_error(y_train, y_pred_train)
test_mse = mean_squared_error(y_test, y_pred_test)
print('Train MSE:', train_mse)
print('Test MSE:', test_mse)


# In[16]:


train_r2 = r2_score(y_train, y_pred_train)
test_r2 = r2_score(y_test, y_pred_test)
print('Train R^2 Score:', train_r2)
print('Test R^2 Score:', test_r2)

