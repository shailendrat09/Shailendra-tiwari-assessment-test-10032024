#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import tensorflow as tf
from tensorflow import keras
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


# In[2]:


# Load the California housing dataset
housing = fetch_california_housing()
X, y = housing.data, housing.target


# In[3]:


# Normalize the features
scaler = StandardScaler()
X = scaler.fit_transform(X)


# In[4]:


# Split the dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[5]:


# Define the model architecture
model = keras.Sequential([
    keras.layers.Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    keras.layers.Dense(32, activation='relu'),
    keras.layers.Dense(1)  # Output layer with single neuron for regression
])


# In[6]:


# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')


# In[7]:


# Train the model
model.fit(X_train, y_train, epochs=100, batch_size=32, validation_split=0.2)


# In[8]:


# Evaluate the model on test data
test_loss = model.evaluate(X_test, y_test)
print("Test Loss:", test_loss)

